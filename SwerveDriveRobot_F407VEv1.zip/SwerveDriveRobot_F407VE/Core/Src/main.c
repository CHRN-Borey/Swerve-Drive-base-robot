/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//MOTOR
 #define MOTOR_L1 TIM_CHANNEL_4
 #define MOTOR_R1 TIM_CHANNEL_3
 #define MOTOR_L2 TIM_CHANNEL_2
 #define MOTOR_R2 TIM_CHANNEL_1

 #define MOTOR_L3 TIM_CHANNEL_4
 #define MOTOR_R3 TIM_CHANNEL_3
 #define MOTOR_L4 TIM_CHANNEL_2
 #define MOTOR_R4 TIM_CHANNEL_1
 //ANGLE
 #define ANGLE_L1 TIM_CHANNEL_4
 #define ANGLE_R1 TIM_CHANNEL_3
 #define ANGLE_L2 TIM_CHANNEL_2
 #define ANGLE_R2 TIM_CHANNEL_1

 #define ANGLE_L3 TIM_CHANNEL_3
 #define ANGLE_R3 TIM_CHANNEL_4
 #define ANGLE_L4 TIM_CHANNEL_1
 #define ANGLE_R4 TIM_CHANNEL_2

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
int encoder1[8] = {0}, last_encoder1[8] = {0};
int encoder2[8] = {0}, last_encoder2[8] = {0};
double counter[8] = {0};

float VX = 0,VY = 0, W = 0, r =2.12;
float Vx0 = 0, Vy0 = 0, speed0 = 0, angle0 = 0;
float Vx1 = 0, Vy1 = 0, speed1 = 0, angle1 = 0;
float Vx2 = 0, Vy2 = 0, speed2 = 0, angle2 = 0;
float Vx3 = 0, Vy3 = 0, speed3 = 0, angle3 = 0;
float A = 0, B = 0, C = 0, D = 0;
float k=0,l=0;



////////////////////////////////////////////RPM and PID V
//int motor_j[4] = {0};
//int position_motor[4] = {0};
//int V_j[4] = {0};

long count[4]= {0};
long count_angle[4]= {0};
long  last_count[4] = {0};
float setpoint[4] =  {0};
float setpoint_minute[4] =  {0};
float RPM[4]= {0};
float RPS[4]= {0};
long last_time[4] =  {0};
int T[4] =  {0};
float count_second[4] =  {0};
float Round[4] =  {0};
double last_time_PID[4] =  {0};
double current_time_PID[4] =  {0};
double eslapedtime[4] =  {0};
float Error[4];
float last_Error[4];
float i_[4] =  {0};
float d_[4] =  {0};
float setpoint_minute_M[4];
double pid[4];
float pwm_M[4] =  {0};

float Kp = 120, Ki = 2.7, Kd = 100;
//float Kp = 120, Ki = 2.7, Kd = 100;

////////////////////////////////////////////PID angle
float BB_=0;
float set_angle=0;
float now_angle[4]= {0};
float setpoint_angle[4] =  {0};
float setpoint_minute_angle[4] =  {0};
long last_time_angle[4] =  {0};
int T_angle[4] =  {0};
double last_time_PID_angle[4] =  {0};
double current_time_PID_angle[4] =  {0};
double eslapedtime_angle[4] =  {0};
float Error_angle[4];
float last_Error_angle[4];
float i__angle[4] =  {0};
float d__angle[4] =  {0};
float setpoint_minute_M_angle[4];
double pid_angle[4];
float pwm_M_angle[4] =  {0};

float Kp_angle = 5, Ki_angle = 0, Kd_angle = 0;
//float Kp = 120, Ki = 2.7, Kd = 100;
////////////////////////////////////////////
long BZ_time = 0;
int BZ_constance = 0;
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

double map(double x, double in_min, double in_max, double out_min, double out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
	if(GPIO_Pin == ENCODER_M_L1_Pin||ENCODER_M_R1_Pin){
		encoder1[0] = HAL_GPIO_ReadPin(ENCODER_M_L1_GPIO_Port, ENCODER_M_L1_Pin);
		encoder2[0] = HAL_GPIO_ReadPin(ENCODER_M_R1_GPIO_Port, ENCODER_M_R1_Pin);
	}
	if(GPIO_Pin == ENCODER_M_L2_Pin||ENCODER_M_R2_Pin){
		encoder1[1] = HAL_GPIO_ReadPin(ENCODER_M_L2_GPIO_Port, ENCODER_M_L2_Pin);
		encoder2[1] = HAL_GPIO_ReadPin(ENCODER_M_R2_GPIO_Port, ENCODER_M_R2_Pin);
	}
	if(GPIO_Pin == ENCODER_M_L3_Pin||ENCODER_M_R3_Pin){
		encoder1[2] = HAL_GPIO_ReadPin(ENCODER_M_L3_GPIO_Port, ENCODER_M_L3_Pin);
		encoder2[2] = HAL_GPIO_ReadPin(ENCODER_M_R3_GPIO_Port, ENCODER_M_R3_Pin);
	}
	if(GPIO_Pin == ENCODER_M_L4_Pin||ENCODER_M_R4_Pin){
		encoder1[3] = HAL_GPIO_ReadPin(ENCODER_M_L4_GPIO_Port, ENCODER_M_L4_Pin);
		encoder2[3] = HAL_GPIO_ReadPin(ENCODER_M_R4_GPIO_Port, ENCODER_M_R4_Pin);
	}
	if(GPIO_Pin == ENCODER_A_L1_Pin||ENCODER_A_R1_Pin){
		encoder1[4] = HAL_GPIO_ReadPin(ENCODER_A_L1_GPIO_Port, ENCODER_A_L1_Pin);
		encoder2[4] = HAL_GPIO_ReadPin(ENCODER_A_R1_GPIO_Port, ENCODER_A_R1_Pin);
	}
	if(GPIO_Pin == ENCODER_A_L2_Pin||ENCODER_A_R2_Pin){
		encoder1[5] = HAL_GPIO_ReadPin(ENCODER_A_L2_GPIO_Port, ENCODER_A_L2_Pin);
		encoder2[5] = HAL_GPIO_ReadPin(ENCODER_A_R2_GPIO_Port, ENCODER_A_R2_Pin);
	}
	if(GPIO_Pin == ENCODER_A_L3_Pin||ENCODER_A_R3_Pin){
		encoder1[6] = HAL_GPIO_ReadPin(ENCODER_A_L3_GPIO_Port, ENCODER_A_L3_Pin);
		encoder2[6] = HAL_GPIO_ReadPin(ENCODER_A_R3_GPIO_Port, ENCODER_A_R3_Pin);
	}
	if(GPIO_Pin == ENCODER_A_L4_Pin||ENCODER_A_R4_Pin){
		encoder1[7] = HAL_GPIO_ReadPin(ENCODER_A_L4_GPIO_Port, ENCODER_A_L4_Pin);
		encoder2[7] = HAL_GPIO_ReadPin(ENCODER_A_R4_GPIO_Port, ENCODER_A_R4_Pin);
	}

}

void Encoder_(){
	for(int i=0; i<8; i++){

		if(encoder1[i] != last_encoder1[i]){
			last_encoder1[i] = encoder1[i];
			if(encoder1[i] == 0){
				if(encoder2[i] == 1){

					counter[i]++;
				}else{
					counter[i]--;
				}
			}else{
				if(encoder2[i] == 0){
					counter[i]++;
				}else{
					counter[i]--;
				}
			}
		}
		if(encoder2[i] != last_encoder2[i]){
			last_encoder2[i] = encoder2[i];
			if(encoder2[i] == 1){
				if(encoder1[i] == 1){
					counter[i]++;
				}else{
					counter[i]--;
				}
			}else{
				if(encoder1[i] == 0){
					counter[i]++;
				}else{
					counter[i]--;
				}
			}
		}
	}
	  count[0] = counter[0];
	  count[1] = counter[1];
	  count[2] = counter[2];
	  count[3] = counter[3];
	  count_angle[0] = counter[4];
	  count_angle[1] = counter[5];
	  count_angle[2] = counter[6];
	  count_angle[3] = counter[7];

}

void swerve_drive(){
	  VX = 100;
	  VY = 100;
	  W = 0;

	  A = VX - W*r;
	  B = VX + W*r;
	  C = VY - W*r;
	  D = VY + W*r;

	  speed0 = sqrt((B*B) + (C*C));
	  speed1 = sqrt((B*B) + (D*D));
	  speed2 = sqrt((A*A) + (D*D));
	  speed3 = sqrt((A*A) + (C*C));

	  angle0 = atan2(B,C)*180/3.141592653589793238462643;
	  angle1 = atan2(B,D)*180/3.141592653589793238462643;
	  angle2 = atan2(A,D)*180/3.141592653589793238462643;
	  angle3 = atan2(A,C)*180/3.141592653589793238462643;
}

void RPM__1() {

	////////////////////////////////////////////

	for (int i=0; i< 4 ;i++){
	  T[i] = HAL_GetTick() - last_time[i];
		  if (T[i] >= 10) {

			count_second[i] =count[i] - last_count[i];
			RPS[i] = (count_second[i] * 100) / 520;
			RPM[i] = (RPS[i] * 60);
			last_count[i] = count[i];
			last_time[i] = HAL_GetTick();
		  }

//			  setpoint_minute[i] = 50;
			  setpoint[i] = (setpoint_minute[i] / 60);
			  current_time_PID[i] = HAL_GetTick();
			  eslapedtime[i] = current_time_PID[i] - last_time_PID[i];
			  Error[i] = setpoint[i] - RPS[i];
			  i_[i] = i_[i] + (Error[i] * eslapedtime[i]);
			  d_[i] = (Error[i] - last_Error[i]) / eslapedtime[i];

			  pid[i] = Kp * Error[i] + Ki * i_[i] + Kd * d_[i];

			  // constrain value
			  if (pid[i] < -500){pwm_M[i] = -500;}
			  if(pid[i] > 500){pwm_M[i] = 500;}
			  if( -500 <= pid[i] && pid[i] <= 500){pwm_M[i] = pid[i];}
			 ////////////////////////
			  last_Error[i] = Error[i];
			  last_time_PID[i] = current_time_PID[i];
	}
}

void RPM__A() {

	////////////////////////////////////////////

	for (int i=0; i< 4 ;i++){
	  T_angle[i] = HAL_GetTick() - last_time_angle[i];

	  	  	  if(now_angle[i] > 180) now_angle[i] = 180;
	  	  	  if(now_angle[i] < 0) now_angle[i] = 0;

//	  	  	  setpoint_angle[i] = map(now_angle[i],0,180,0,1120);
	  	  	setpoint_angle[0] = map(now_angle[0],0,180,0,1230);
	  	    setpoint_angle[1] = map(now_angle[1],0,180,0,1210);
	  	    setpoint_angle[2] = map(now_angle[2],0,180,0,850);
	  	    setpoint_angle[3] = map(now_angle[3],0,180,0,940);

			  current_time_PID_angle[i] = HAL_GetTick();
			  eslapedtime_angle[i] = current_time_PID_angle[i] - last_time_PID_angle[i];
			  Error_angle[i] = setpoint_angle[i] - count_angle[i];
			  i__angle[i] = i__angle[i] + (Error_angle[i] * eslapedtime_angle[i]);
			  d__angle[i] = (Error_angle[i] - last_Error_angle[i]) / eslapedtime_angle[i];

			  pid_angle[i] = Kp_angle * Error_angle[i] + Ki_angle * i__angle[i] + Kd_angle * d__angle[i];

			 // pwm_M[i] = pid[i];  //No constrain value

			  // constrain value
			  if (pid_angle[i] < -500){pwm_M_angle[i] = -500;}
			  if(pid_angle[i] > 500){pwm_M_angle[i] = 500;}
			  if( -500 <= pid_angle[i] && pid_angle[i] <= 500){pwm_M_angle[i] = pid_angle[i];}
			  ///
			  last_Error_angle[i] = Error_angle[i];
			  last_time_PID_angle[i] = current_time_PID_angle[i];
	}
}

void BZ_C13(){
	for (int i = 0; i<2 ; i++){
		HAL_Delay(500);
		for (int j = 0; j < 8; j++){
			HAL_GPIO_TogglePin(LEDC13_GPIO_Port, LEDC13_Pin);
			HAL_GPIO_TogglePin(BZA15_GPIO_Port, BZA15_Pin);
			HAL_Delay(30);
		}
	}
}

void Motor_speed(){
		  //M1
		  if(pwm_M[0] > 0){
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_L1,pwm_M[0]);
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_R1,0);
		  }
		  if(pwm_M[0] < 0){
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_L1,0);
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_R1,(-1)*pwm_M[0]);
		  }
		  if(pwm_M[0] == 0){
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_L1,0);
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_R1,0);
		  }
		  //M2
		  if(pwm_M[1] > 0){
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_L2,pwm_M[1]);
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_R2,0);
		  }
		  if(pwm_M[1] < 0){
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_L2,0);
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_R2,(-1)*pwm_M[1]);
		  }
		  if(pwm_M[1] == 0){
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_L2,0);
		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_R2,0);
		  }
		  //M3
		  if(pwm_M[2] > 0){
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_L3,pwm_M[2]);
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_R3,0);
		  }
		  if(pwm_M[2] < 0){
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_L3,0);
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_R3,(-1)*pwm_M[2]);
		  }
		  if(pwm_M[2] == 0){
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_L3,0);
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_R3,0);
		  }
		  //M4
		  if(pwm_M[3] > 0){
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_L4,pwm_M[3]);
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_R4,0);
		  }
		  if(pwm_M[3] < 0){
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_L4,0);
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_R4,(-1)*pwm_M[3]);
		  }
		  if(pwm_M[3] == 0){
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_L4,0);
		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_R4,0);
		  }

		  //	  		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_L1,100);
		  //	  		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_R1,0);
		  //	  		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_L2,100);
		  //	  		  __HAL_TIM_SET_COMPARE(&htim1, MOTOR_R2,0);
		  //	  		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_L3,0);
		  //	  		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_R3,100);
		  //	  		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_L4,0);
		  //	  		  __HAL_TIM_SET_COMPARE(&htim3, MOTOR_R4,100);
}

void motor_angle(){//2220

	  //M1
	  if(pwm_M_angle[0] > 0){
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_L1,pwm_M_angle[0]);
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_R1,0);
	  }
	  if(pwm_M_angle[0] < 0){
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_L1,0);
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_R1,(-1)*pwm_M_angle[0]);
	  }
	  if(pwm_M_angle[0] == 0){
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_L1,0);
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_R1,0);
	  }
	  //M2
	  if(pwm_M_angle[1] > 0){
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_L2,pwm_M_angle[1]);
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_R2,0);
	  }
	  if(pwm_M_angle[1] < 0){
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_L2,0);
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_R2,(-1)*pwm_M_angle[1]);
	  }
	  if(pwm_M_angle[1] == 0){
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_L2,0);
	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_R2,0);
	  }
	  //M3
	  if(pwm_M_angle[2] > 0){
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_L3,pwm_M_angle[2]);
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_R3,0);
	  }
	  if(pwm_M_angle[2] < 0){
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_L3,0);
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_R3,(-1)*pwm_M_angle[2]);
	  }
	  if(pwm_M_angle[2] == 0){
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_L3,0);
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_R3,0);
	  }
	  //M4
	  if(pwm_M_angle[3] > 0){
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_L4,pwm_M_angle[3]);
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_R4,0);
	  }
	  if(pwm_M_angle[3] < 0){
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_L4,0);
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_R4,(-1)*pwm_M_angle[3]);
	  }
	  if(pwm_M_angle[3] == 0){
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_L4,0);
	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_R4,0);
	  }



//	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_L1,100);
//	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_R1,0);
//	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_L2,100);
//	  __HAL_TIM_SET_COMPARE(&htim4, ANGLE_R2,0);
//
//	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_L3,100);
//	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_R3,0);
//	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_L4,100);
//	  __HAL_TIM_SET_COMPARE(&htim5, ANGLE_R4,0);
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM5_Init();
  /* USER CODE BEGIN 2 */
//  	  BZ_C13();
//MOTOR
  HAL_TIM_PWM_Start(&htim1, MOTOR_L1);
  HAL_TIM_PWM_Start(&htim1, MOTOR_R1);
  HAL_TIM_PWM_Start(&htim1, MOTOR_L2);
  HAL_TIM_PWM_Start(&htim1, MOTOR_R2);

  HAL_TIM_PWM_Start(&htim3, MOTOR_L3);
  HAL_TIM_PWM_Start(&htim3, MOTOR_R3);
  HAL_TIM_PWM_Start(&htim3, MOTOR_L4);
  HAL_TIM_PWM_Start(&htim3, MOTOR_R4);
//ANGLE
  HAL_TIM_PWM_Start(&htim4, ANGLE_L1);
  HAL_TIM_PWM_Start(&htim4, ANGLE_R1);
  HAL_TIM_PWM_Start(&htim4, ANGLE_L2);
  HAL_TIM_PWM_Start(&htim4, ANGLE_R2);

  HAL_TIM_PWM_Start(&htim5, ANGLE_L3);
  HAL_TIM_PWM_Start(&htim5, ANGLE_R3);
  HAL_TIM_PWM_Start(&htim5, ANGLE_L4);
  HAL_TIM_PWM_Start(&htim5, ANGLE_R4);

  for(int i = 0; i < 4; i++){
	  last_time_PID[i] = HAL_GetTick();
	  last_time_angle[i] = HAL_GetTick();
  }
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  Encoder_();
	  RPM__1();
	  Motor_speed();
	  RPM__A();
	  motor_angle();

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 15;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
